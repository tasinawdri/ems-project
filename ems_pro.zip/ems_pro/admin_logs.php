<?php
session_start();
require 'config.php';
require 'functions.php';

// 1. Security Check: Only Admins
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Session Hijacking Validation
validate_session_security();// 2. Fetch Logs (Joined with Users table to get names)
$sql = "SELECT logs.*, users.username, users.role 
        FROM activity_logs AS logs 
        LEFT JOIN users ON logs.user_id = users.id 
        ORDER BY logs.created_at DESC";
$stmt = $pdo->query($sql);
$logs = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Audit Logs | EMS Pro</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css">
</head>
<body class="bg-light">

    <nav class="navbar navbar-dark bg-dark mb-4">
        <div class="container-fluid">
            <span class="navbar-brand mb-0 h1"><i class="fa-solid fa-shield-halved me-2"></i> Audit Logs</span>
            <a href="index.php" class="btn btn-outline-light btn-sm">Back to Dashboard</a>
        </div>
    </nav>

    <div class="container">
        <div class="card shadow-sm border-0">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0 text-secondary">System Activity History</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="logsTable" class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>Time</th>
                                <th>User</th>
                                <th>Role</th>
                                <th>Action</th>
                                <th>Description</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($logs as $log): ?>
                            <tr>
                                <td class="text-nowrap text-muted small">
                                    <?= date('M d, Y h:i A', strtotime($log['created_at'])) ?>
                                </td>
                                <td class="fw-bold">
                                    <?= htmlspecialchars($log['username'] ?? 'Unknown User') ?>
                                </td>
                                <td>
                                    <?php if(($log['role'] ?? '') == 'admin'): ?>
                                        <span class="badge bg-danger">Admin</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">Staff</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php 
                                        // Color code specific actions
                                        $color = 'primary';
                                        if($log['action'] == 'Login') $color = 'success';
                                        if(strpos($log['action'], 'Delete') !== false) $color = 'danger';
                                        if(strpos($log['action'], 'Update') !== false) $color = 'warning text-dark';
                                    ?>
                                    <span class="badge bg-<?= $color ?>"><?= $log['action'] ?></span>
                                </td>
                                <td class="text-secondary small">
                                    <?= htmlspecialchars($log['description']) ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
    <script>
        $(document).ready(function () {
            $('#logsTable').DataTable({
                "order": [[ 0, "desc" ]] // Sort by date descending
            });
        });
    </script>
</body>
</html>