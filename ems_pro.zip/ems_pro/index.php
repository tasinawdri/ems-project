<?php
session_start();
require 'config.php';
require 'functions.php';

// 1. Auth Check
if (!isset($_SESSION['user_id'])) { 
    header("Location: login.php"); 
    exit; 
}

// 2. Session Hijacking Validation
validate_session_security();

// 2. Dashboard Analytics Logic
$today = date('Y-m-d');
$total_emp = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$present_today = $pdo->query("SELECT COUNT(*) FROM attendance WHERE date = '$today'")->fetchColumn();
$pending_leaves = $pdo->query("SELECT COUNT(*) FROM leaves WHERE status = 'Pending'")->fetchColumn();
$notices = $pdo->query("SELECT * FROM notices ORDER BY date DESC LIMIT 3")->fetchAll();

// Chart Data
$dept_data = $pdo->query("SELECT d.name, COUNT(u.id) as count FROM departments d LEFT JOIN users u ON d.id=u.department_id GROUP BY d.name")->fetchAll(PDO::FETCH_ASSOC);
$dept_names = json_encode(array_column($dept_data, 'name'));
$dept_counts = json_encode(array_column($dept_data, 'count'));

// Employees Table
$search = $_GET['search'] ?? '';
$sql = "SELECT u.*, d.name as dept_name FROM users u LEFT JOIN departments d ON u.department_id = d.id WHERE u.username LIKE ?";
$stmt = $pdo->prepare($sql);
$stmt->execute(["%$search%"]);
$employees = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>EMS Pro Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body { background-color: #f0f2f5; font-family: 'Segoe UI', sans-serif; }
        #wrapper { display: flex; width: 100%; }
        #sidebar-wrapper { min-height: 100vh; width: 250px; background: #212529; color: #fff; }
        .sidebar-heading { padding: 1.5rem 1.25rem; font-size: 1.2rem; font-weight: bold; background: #00000020; }
        .list-group-item { background-color: transparent; border: none; color: #bbb; padding: 12px 20px; }
        .list-group-item:hover { background-color: #343a40; color: #fff; }
        .list-group-item.active { background-color: #0d6efd; color: white; }
        #page-content-wrapper { width: 100%; padding: 20px; }
        .stat-card { border: none; border-radius: 15px; color: white; transition: transform 0.3s; }
        .stat-card:hover { transform: translateY(-5px); }
        .bg-gradient-primary { background: linear-gradient(45deg, #4e73df, #224abe); }
        .bg-gradient-success { background: linear-gradient(45deg, #1cc88a, #13855c); }
        .bg-gradient-warning { background: linear-gradient(45deg, #f6c23e, #dda20a); }
        .bg-gradient-info { background: linear-gradient(45deg, #36b9cc, #258391); }
        .notice-item { border-left: 4px solid #0d6efd; background: white; padding: 10px; margin-bottom: 10px; border-radius: 4px; }
    </style>
</head>
<body>

<div class="d-flex" id="wrapper">

    <div class="border-end" id="sidebar-wrapper">
        <div class="sidebar-heading text-center"><i class="fa-solid fa-cube"></i> EMS PRO</div>
        <div class="list-group list-group-flush">
            <a href="index.php" class="list-group-item active"><i class="fa-solid fa-gauge me-2"></i> Dashboard</a>
            
            <div class="text-uppercase small text-muted px-3 mt-3 mb-1">Employee Menu</div>
            <a href="attendance.php" class="list-group-item"><i class="fa-solid fa-clock me-2"></i> Attendance</a>
            <a href="apply_leave.php" class="list-group-item"><i class="fa-solid fa-calendar-plus me-2"></i> Apply Leave</a>
            <a href="my_tasks.php" class="list-group-item"><i class="fa-solid fa-list-check me-2"></i> My Tasks</a>
            
            <a href="my_expenses.php" class="list-group-item"><i class="fa-solid fa-receipt me-2"></i> My Expenses</a>
            
            <a href="my_salary.php" class="list-group-item"><i class="fa-solid fa-file-invoice-dollar me-2"></i> Payslips</a>

            <?php if ($_SESSION['role'] == 'admin'): ?>
                <div class="text-uppercase small text-muted px-3 mt-3 mb-1">Admin Tools</div>
                <a href="create.php" class="list-group-item"><i class="fa-solid fa-user-plus me-2"></i> Add Employee</a>
                <a href="admin_tasks.php" class="list-group-item"><i class="fa-solid fa-thumbtack me-2"></i> Assign Tasks</a>
                <a href="admin_leaves.php" class="list-group-item"><i class="fa-solid fa-check-double me-2"></i> Leave Approvals</a>
                
                <a href="admin_expenses.php" class="list-group-item"><i class="fa-solid fa-money-check-dollar me-2"></i> Expense Approvals</a>
                
                <a href="admin_payroll.php" class="list-group-item"><i class="fa-solid fa-calculator me-2"></i> Payroll</a>
                <a href="admin_notices.php" class="list-group-item"><i class="fa-solid fa-bullhorn me-2"></i> Notices</a>
                <a href="admin_reports.php" class="list-group-item"><i class="fa-solid fa-file-csv me-2"></i> Reports</a>
                <a href="admin_logs.php" class="list-group-item"><i class="fa-solid fa-shield-halved me-2"></i> Audit Logs</a>
            <?php endif; ?>

            <a href="logout.php" class="list-group-item text-danger mt-3"><i class="fa-solid fa-power-off me-2"></i> Logout</a>
        </div>
    </div>
    <div id="page-content-wrapper">
        <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm rounded mb-4 px-4">
            <div class="d-flex align-items-center w-100 justify-content-between">
                <h4 class="m-0 text-primary">Dashboard Overview</h4>
                <div class="d-flex align-items-center">
                    <span class="me-3 fw-bold text-dark"><?= $_SESSION['username'] ?> (<?= ucfirst($_SESSION['role']) ?>)</span>
                    <img src="uploads/<?= $_SESSION['avatar'] ?>" width="40" height="40" class="rounded-circle border">
                </div>
            </div>
        </nav>

        <div class="container-fluid">
            <div class="row g-3 mb-4">
                <div class="col-md-3">
                    <div class="card stat-card bg-gradient-primary shadow p-3">
                        <div class="d-flex justify-content-between align-items-center">
                            <div><h6 class="text-uppercase mb-1">Total Employees</h6><h2 class="mb-0 fw-bold"><?= $total_emp ?></h2></div>
                            <i class="fa-solid fa-users fa-2x opacity-50"></i>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card stat-card bg-gradient-success shadow p-3">
                        <div class="d-flex justify-content-between align-items-center">
                            <div><h6 class="text-uppercase mb-1">Present Today</h6><h2 class="mb-0 fw-bold"><?= $present_today ?></h2></div>
                            <i class="fa-solid fa-user-check fa-2x opacity-50"></i>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card stat-card bg-gradient-warning shadow p-3">
                        <div class="d-flex justify-content-between align-items-center">
                            <div><h6 class="text-uppercase mb-1">Pending Leaves</h6><h2 class="mb-0 fw-bold"><?= $pending_leaves ?></h2></div>
                            <i class="fa-solid fa-hourglass-half fa-2x opacity-50"></i>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card stat-card bg-gradient-info shadow p-3">
                        <div class="d-flex justify-content-between align-items-center">
                            <div><h6 class="text-uppercase mb-1">Date</h6><h5 class="mb-0"><?= date('M d, Y') ?></h5></div>
                            <i class="fa-regular fa-calendar-days fa-2x opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row g-3 mb-4">
                <div class="col-lg-8">
                    <div class="card shadow-sm border-0 h-100">
                        <div class="card-header bg-white fw-bold">Department Distribution</div>
                        <div class="card-body"><canvas id="deptChart" style="max-height: 250px;"></canvas></div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card shadow-sm border-0 h-100">
                        <div class="card-header bg-white fw-bold d-flex justify-content-between">
                            <span><i class="fa-solid fa-bell text-warning"></i> Notice Board</span>
                            <?php if($_SESSION['role']=='admin'): ?><a href="admin_notices.php" class="small text-decoration-none">Manage</a><?php endif; ?>
                        </div>
                        <div class="card-body bg-light">
                            <?php foreach($notices as $n): ?>
                            <div class="notice-item shadow-sm">
                                <small class="text-muted d-block"><?= date('M d, Y', strtotime($n['date'])) ?></small>
                                <strong><?= htmlspecialchars($n['title']) ?></strong>
                                <p class="mb-0 small text-secondary"><?= htmlspecialchars($n['message']) ?></p>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="card shadow-sm border-0">
                <div class="card-header bg-white d-flex justify-content-between align-items-center">
                    <h5 class="mb-0 text-primary fw-bold">Employee Directory</h5>
                    <div class="d-flex">
                        <input id="searchInput" name="search" class="form-control form-control-sm me-2" placeholder="Search by name or email..." value="<?= htmlspecialchars($search) ?>">
                        <small class="text-muted align-self-center">Instant search</small>
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr><th>Avatar</th><th>Name</th><th>Email</th><th>Dept</th><th>Role</th><?php if($_SESSION['role']=='admin') echo "<th>Action</th>"; ?></tr>
                        </thead>
                        <tbody>
                            <?php foreach ($employees as $emp): ?>
                            <tr>
                                <td><img src="uploads/<?= $emp['avatar'] ?>" width="35" height="35" class="rounded-circle border"></td>
                                <td class="fw-bold"><?= htmlspecialchars($emp['username']) ?></td>
                                <td><?= htmlspecialchars($emp['email']) ?></td>
                                <td><span class="badge bg-secondary"><?= htmlspecialchars($emp['dept_name']) ?></span></td>
                                <td><?= ucfirst($emp['role']) ?></td>
                                <?php if ($_SESSION['role'] == 'admin'): ?>
                                <td>
                                    <a href="edit.php?id=<?= $emp['id'] ?>" class="btn btn-sm btn-outline-primary"><i class="fa-solid fa-pen"></i></a>
                                    <a href="delete.php?id=<?= $emp['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete?')"><i class="fa-solid fa-trash"></i></a>
                                </td>
                                <?php endif; ?>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
</div>

<script>
    // Department Chart
    new Chart(document.getElementById('deptChart'), {
        type: 'bar',
        data: {
            labels: <?= $dept_names ?>,
            datasets: [{
                label: 'Employees',
                data: <?= $dept_counts ?>,
                backgroundColor: ['#4e73df', '#1cc88a', '#36b9cc', '#f6c23e', '#e74a3b'],
                borderRadius: 5
            }]
        },
        options: { responsive: true, maintainAspectRatio: false }
    });

    // Real-Time AJAX Search
    const searchInput = document.getElementById('searchInput');
    const tableBody = document.querySelector('table tbody');

    searchInput.addEventListener('keyup', function() {
        const searchTerm = this.value.trim();
        
        // Show loading state
        tableBody.innerHTML = '<tr><td colspan="6" class="text-center text-muted py-3"><i class="fa-solid fa-spinner fa-spin"></i> Searching...</td></tr>';
        
        // Fetch matching results
        fetch('search_ajax.php?search=' + encodeURIComponent(searchTerm))
            .then(response => response.text())
            .then(data => {
                // Update table with results
                if (data.trim() === '') {
                    tableBody.innerHTML = '<tr><td colspan="6" class="text-center text-muted py-3">No employees found</td></tr>';
                } else {
                    tableBody.innerHTML = data;
                }
            })
            .catch(error => {
                console.error('Search error:', error);
                tableBody.innerHTML = '<tr><td colspan="6" class="text-center text-danger py-3">Error loading results</td></tr>';
            });
    });
</script>

</body>
</html>