<?php
session_start();
require 'config.php';
require 'functions.php';

// Validate session
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    exit;
}

// Validate session security
validate_session_security();

// Get search term from query parameter
$search = $_GET['search'] ?? '';
$search = trim($search);

// Fetch employees matching search term
$sql = "SELECT u.*, d.name as dept_name FROM users u LEFT JOIN departments d ON u.department_id = d.id WHERE u.username LIKE ? OR u.email LIKE ? ORDER BY u.username ASC";
$stmt = $pdo->prepare($sql);
$stmt->execute(["%$search%", "%$search%"]);
$employees = $stmt->fetchAll();

// Generate table rows HTML
foreach ($employees as $emp) {
    ?>
    <tr>
        <td><img src="uploads/<?= htmlspecialchars($emp['avatar']) ?>" width="35" height="35" class="rounded-circle border"></td>
        <td class="fw-bold"><?= htmlspecialchars($emp['username']) ?></td>
        <td><?= htmlspecialchars($emp['email']) ?></td>
        <td><span class="badge bg-secondary"><?= htmlspecialchars($emp['dept_name'] ?? 'N/A') ?></span></td>
        <td><?= ucfirst(htmlspecialchars($emp['role'])) ?></td>
        <?php if ($_SESSION['role'] == 'admin'): ?>
        <td>
            <a href="edit.php?id=<?= $emp['id'] ?>" class="btn btn-sm btn-outline-primary"><i class="fa-solid fa-pen"></i></a>
            <a href="delete.php?id=<?= $emp['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete?')"><i class="fa-solid fa-trash"></i></a>
        </td>
        <?php endif; ?>
    </tr>
    <?php
}
?>
