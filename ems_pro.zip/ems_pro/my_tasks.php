<?php
session_start();
require 'config.php';
require 'functions.php';
// Session Hijacking Validation
validate_session_security();
if (isset($_GET['start'])) $pdo->prepare("UPDATE tasks SET status='In Progress' WHERE id=?")->execute([$_GET['start']]);
if (isset($_GET['finish'])) $pdo->prepare("UPDATE tasks SET status='Completed' WHERE id=?")->execute([$_GET['finish']]);

$stmt = $pdo->prepare("SELECT * FROM tasks WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$tasks = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html>
<head><title>My Tasks</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body class="container mt-5">
    <h3>My Tasks</h3>
    <table class="table table-hover">
        <thead><tr><th>Task</th><th>Description</th><th>Due Date</th><th>Status</th><th>Action</th></tr></thead>
        <tbody>
            <?php foreach($tasks as $t): ?>
            <tr>
                <td><?= $t['task_name'] ?></td>
                <td><?= $t['description'] ?></td>
                <td><?= $t['due_date'] ?></td>
                <td><?= $t['status'] ?></td>
                <td>
                    <?php if ($t['status'] == 'Pending'): ?>
                        <a href="?start=<?= $t['id'] ?>" class="btn btn-warning btn-sm">Start</a>
                    <?php elseif ($t['status'] == 'In Progress'): ?>
                        <a href="?finish=<?= $t['id'] ?>" class="btn btn-success btn-sm">Finish</a>
                    <?php else: ?>
                        <span class="text-success">Done</span>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <a href="index.php" class="btn btn-secondary">Back</a>
</body>
</html>   