<?php
session_start();
require 'config.php';
require 'functions.php';

// Security: Admin Only
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    die("Access Denied");
}

// Session Hijacking Validation
validate_session_security();

// --- CSV EXPORT LOGIC ---
if (isset($_POST['export'])) {
    $type = $_POST['report_type'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];
    $filename = "report_" . $type . "_" . date('Ymd') . ".csv";

    // Set Headers to force download
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    $output = fopen('php://output', 'w');

    if ($type == 'attendance') {
        // Attendance Report Header
        fputcsv($output, ['ID', 'Employee Name', 'Date', 'Status', 'Clock In', 'Clock Out']);
        
        // Fetch Data
        $sql = "SELECT a.id, u.username, a.date, a.status, a.clock_in, a.clock_out 
                FROM attendance a 
                JOIN users u ON a.user_id = u.id 
                WHERE a.date BETWEEN ? AND ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$start_date, $end_date]);
        
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            fputcsv($output, $row);
        }

    } elseif ($type == 'leaves') {
        // Leave Report Header
        fputcsv($output, ['Employee', 'Type', 'Start Date', 'End Date', 'Reason', 'Status']);
        
        // Fetch Data
        $sql = "SELECT a.id, u.username, a.date, 'Present' as status, a.clock_in, a.clock_out 
        FROM attendance a 
        JOIN users u ON a.user_id = u.id 
        WHERE a.date BETWEEN ? AND ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$start_date, $end_date]);
        
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            fputcsv($output, $row);
        }
    }
    
    fclose($output);
    exit; // Stop script so HTML below doesn't get added to CSV
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Reports | EMS Pro</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-light">

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow border-0">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0"><i class="fa-solid fa-file-export me-2"></i> Generate Reports</h5>
                </div>
                <div class="card-body p-4">
                    <p class="text-muted">Select the type of report and the date range to download a CSV file compatible with Excel.</p>
                    
                    <form method="POST">
                        
                        <div class="mb-3">
                            <label class="form-label fw-bold">Report Type</label>
                            <select name="report_type" class="form-select" required>
                                <option value="attendance">Attendance Report</option>
                                <option value="leaves">Leave Requests Report</option>
                            </select>
                        </div>

                        <div class="row mb-4">
                            <div class="col">
                                <label class="form-label fw-bold">From Date</label>
                                <input type="date" name="start_date" class="form-control" value="<?= date('Y-m-01') ?>" required>
                            </div>
                            <div class="col">
                                <label class="form-label fw-bold">To Date</label>
                                <input type="date" name="end_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
                            </div>
                        </div>

                        <div class="d-grid gap-2">
                            <button type="submit" name="export" class="btn btn-success btn-lg">
                                <i class="fa-solid fa-download me-2"></i> Download Report (CSV)
                            </button>
                            <a href="index.php" class="btn btn-secondary">Back to Dashboard</a>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>