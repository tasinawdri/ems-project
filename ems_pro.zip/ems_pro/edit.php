<?php
session_start();
require 'config.php';
require 'functions.php';

// Session Hijacking Validation
validate_session_security();
if ($_SESSION['role'] != 'admin') header("Location: index.php");

$id = $_GET['id'];
$u = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$u->execute([$id]);
$user = $u->fetch();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $sql = "UPDATE users SET username=?, email=?, role=?, base_salary=? WHERE id=?";
    $pdo->prepare($sql)->execute([$_POST['username'], $_POST['email'], $_POST['role'], $_POST['base_salary'], $id]);
    header("Location: index.php");
}
?>
<!DOCTYPE html>
<html>
<head><title>Edit User</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body class="container mt-5">
    <div class="card p-4 mx-auto" style="max-width: 500px;">
        <h3>Edit Employee</h3>
        <form method="POST">
            <div class="mb-2"><label>Name</label><input type="text" name="username" value="<?= $user['username'] ?>" class="form-control"></div>
            <div class="mb-2"><label>Email</label><input type="email" name="email" value="<?= $user['email'] ?>" class="form-control"></div>
            <div class="mb-2"><label>Role</label>
                <select name="role" class="form-control">
                    <option value="employee" <?= $user['role']=='employee'?'selected':'' ?>>Employee</option>
                    <option value="admin" <?= $user['role']=='admin'?'selected':'' ?>>Admin</option>
                </select>
            </div>
            <div class="mb-3"><label>Salary</label><input type="number" name="base_salary" value="<?= $user['base_salary'] ?>" class="form-control"></div>
            <button class="btn btn-primary w-100">Update</button>
            <a href="index.php" class="btn btn-secondary w-100 mt-2">Cancel</a>
        </form>
    </div>
</body>
</html>