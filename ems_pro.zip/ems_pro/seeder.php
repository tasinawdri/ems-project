<?php
require 'config.php';

try {
    echo "<h3>🌱 Seeding Database...</h3>";

    // 1. DISABLE CHECKS & CLEAR DATA
    // We must disable FK checks to truncate tables that are linked
    $pdo->exec("SET FOREIGN_KEY_CHECKS=0");

    $tables = ['users', 'departments', 'attendance', 'leaves', 'expenses', 'tasks', 'notices', 'payroll'];
    foreach($tables as $t) { 
        // Only truncate if table exists to avoid errors on fresh install
        try {
            $pdo->query("TRUNCATE TABLE $t"); 
        } catch (Exception $e) {
            // Table might not exist yet, which is fine
        }
    }
    
    $pdo->exec("SET FOREIGN_KEY_CHECKS=1");
    echo "✅ Old data cleared.<br>";

    // --- 2. SEED DEPARTMENTS ---
    $depts = ['IT Department', 'HR & Admin', 'Sales', 'Marketing', 'Finance'];
    $stmt = $pdo->prepare("INSERT INTO departments (name) VALUES (?)");
    foreach ($depts as $d) {
        $stmt->execute([$d]);
    }
    echo "✅ Departments created.<br>";

    // --- 3. SEED USERS ---
    $password = password_hash("123456", PASSWORD_DEFAULT); // Default pass: 123456

    // Create Admin
    $stmt = $pdo->prepare("INSERT INTO users (username, email, password, role, department_id, base_salary) VALUES (?,?,?,?,?,?)");
    $stmt->execute(['Super Admin', 'admin@ems.com', $password, 'admin', 1, 10000]);

    // Create Employees
    $names = ['John Doe', 'Jane Smith', 'Alice Johnson', 'Bob Brown', 'Charlie Davis'];
    $i = 1;
    foreach ($names as $name) {
        $email = strtolower(str_replace(' ', '.', $name)) . "@ems.com";
        $dept_id = rand(1, 5);
        $salary = rand(3000, 8000);
        $stmt->execute([$name, $email, $password, 'employee', $dept_id, $salary]);
        $i++;
    }
    echo "✅ Users created (Pass: 123456).<br>";

    // --- 4. SEED ATTENDANCE (Last 7 Days) ---
    $users = $pdo->query("SELECT id FROM users")->fetchAll(PDO::FETCH_COLUMN);
    $statuses = ['Present', 'Present', 'Present', 'Late', 'Absent']; 

    foreach ($users as $uid) {
        for ($d = 6; $d >= 0; $d--) {
            $date = date('Y-m-d', strtotime("-$d days"));
            $status = $statuses[array_rand($statuses)];
            
            $in = ($status != 'Absent') ? "09:00:00" : null;
            $out = ($status != 'Absent') ? "17:00:00" : null;
            
            $sql = "INSERT INTO attendance (user_id, date, clock_in, clock_out, status) VALUES (?,?,?,?,?)";
            $pdo->prepare($sql)->execute([$uid, $date, $in, $out, $status]);
        }
    }
    echo "✅ Attendance records generated.<br>";

    // --- 5. SEED LEAVES ---
    foreach ($users as $uid) {
        if (rand(0, 1)) { 
            $start = date('Y-m-d', strtotime("+".rand(1,10)." days"));
            $end = date('Y-m-d', strtotime($start . "+".rand(1,3)." days"));
            $status = ['Pending', 'Approved', 'Rejected'][rand(0,2)];
            
            $pdo->prepare("INSERT INTO leaves (user_id, leave_type, start_date, end_date, reason, status) VALUES (?,?,?,?,?,?)")
                ->execute([$uid, 'Sick', $start, $end, 'Feeling unwell', $status]);
        }
    }
    echo "✅ Leave requests generated.<br>";

    // --- 6. SEED NOTICES ---
    $pdo->prepare("INSERT INTO notices (title, message, date) VALUES (?,?,?)")
        ->execute(['Office Holiday', 'The office will remain closed this Friday.', date('Y-m-d')]);
    echo "✅ Notices posted.<br>";

    echo "<hr><h3 style='color:green'>🎉 Database Seeding Complete!</h3>";
    echo "<a href='login.php'>Go to Login</a>";

} catch (PDOException $e) {
    die("Seeding Failed: " . $e->getMessage());
}
?>