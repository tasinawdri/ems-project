<?php
session_start();
require 'config.php';
require 'functions.php'; // Include for logging

// Session Hijacking Validation
validate_session_security();

// Security Check
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header("Location: index.php");
    exit;
}

// Handle Actions
if (isset($_GET['approve'])) {
    $id = $_GET['approve'];
    $pdo->prepare("UPDATE expenses SET status='Approved' WHERE id=?")->execute([$id]);
    log_activity($_SESSION['user_id'], "Expense Approval", "Approved expense ID: $id");
    header("Location: admin_expenses.php");
    exit;
}
if (isset($_GET['reject'])) {
    $id = $_GET['reject'];
    $pdo->prepare("UPDATE expenses SET status='Rejected' WHERE id=?")->execute([$id]);
    log_activity($_SESSION['user_id'], "Expense Rejection", "Rejected expense ID: $id");
    header("Location: admin_expenses.php");
    exit;
}

// Fetch Pending Expenses
$pending = $pdo->query("SELECT e.*, u.username FROM expenses e JOIN users u ON e.user_id=u.id WHERE e.status='Pending'")->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Expenses</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="container mt-5">
    <div class="d-flex justify-content-between mb-4">
        <h3><i class="fa-solid fa-money-check-dollar"></i> Expense Approvals</h3>
        <a href="index.php" class="btn btn-secondary">Dashboard</a>
    </div>

    <div class="card shadow-sm">
        <div class="card-body p-0">
            <table class="table table-hover mb-0 align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>Employee</th>
                        <th>Expense</th>
                        <th>Amount</th>
                        <th>Description</th>
                        <th>Receipt</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($pending as $e): ?>
                    <tr>
                        <td class="fw-bold"><?= htmlspecialchars($e['username']) ?></td>
                        <td>
                            <?= htmlspecialchars($e['title']) ?> <br> 
                            <small class="text-muted"><?= $e['date'] ?></small>
                        </td>
                        <td class="fw-bold text-success">$<?= number_format($e['amount'], 2) ?></td>
                        <td><?= htmlspecialchars($e['description']) ?></td>
                        <td>
                            <?php if($e['receipt']): ?>
                                <a href="uploads/<?= $e['receipt'] ?>" target="_blank" class="btn btn-sm btn-outline-dark border">
                                    <i class="fa-solid fa-eye"></i> View
                                </a>
                            <?php else: echo "-"; endif; ?>
                        </td>
                        <td>
                            <a href="?approve=<?= $e['id'] ?>" class="btn btn-success btn-sm"><i class="fa-solid fa-check"></i></a>
                            <a href="?reject=<?= $e['id'] ?>" class="btn btn-danger btn-sm"><i class="fa-solid fa-xmark"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if(count($pending)==0) echo "<tr><td colspan='6' class='text-center p-4 text-muted'>No pending claims found.</td></tr>"; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>