<?php
session_start();
require 'config.php';

// If user is already logged in, redirect to dashboard
if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

$error = "";

// Check for session hijacking error from redirect
if (isset($_GET['error']) && $_GET['error'] == 'hijack_attempt') {
    $error = "Session hijacking detected! Your session was terminated for security reasons. Please log in again.";
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    // Check if user exists
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        // Success: Set Session Variables
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['role'] = $user['role'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['avatar'] = $user['avatar'] ?? 'default.png';
        
        // Session Hijacking Protection: Bind session to User Agent and IP Address
        $_SESSION['user_agent'] = $_SERVER['HTTP_USER_AGENT'];
        $_SESSION['ip_address'] = $_SERVER['REMOTE_ADDR'];

        header("Location: index.php");
        exit;
    } else {
        $error = "Invalid email or password.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | EMS Pro</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Segoe UI', sans-serif;
        }
        .login-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 40px;
            width: 100%;
            max-width: 400px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.2);
        }
        .brand-logo {
            width: 70px; height: 70px;
            background: linear-gradient(45deg, #0d6efd, #0dcaf0);
            border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            margin: 0 auto 20px auto; color: white; font-size: 28px;
            box-shadow: 0 4px 15px rgba(13, 110, 253, 0.4);
        }
        .btn-login {
            background: linear-gradient(45deg, #0d6efd, #6610f2);
            border: none;
            transition: transform 0.2s;
        }
        .btn-login:hover { transform: scale(1.02); }
    </style>
</head>
<body>

    <div class="login-card">
        <div class="brand-logo"><i class="fa-solid fa-cube"></i></div>
        <h3 class="text-center fw-bold mb-1">Welcome Back</h3>
        <p class="text-center text-muted mb-4">Sign in to your account</p>

        <?php if($error): ?>
            <div class="alert alert-danger py-2 text-center"><?= $error; ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="mb-3">
                <div class="input-group">
                    <span class="input-group-text bg-white border-end-0"><i class="fa-solid fa-envelope text-muted"></i></span>
                    <input type="email" name="email" class="form-control border-start-0" placeholder="Email Address" required>
                </div>
            </div>

            <div class="mb-4">
                <div class="input-group">
                    <span class="input-group-text bg-white border-end-0"><i class="fa-solid fa-lock text-muted"></i></span>
                    <input type="password" name="password" class="form-control border-start-0" placeholder="Password" required>
                </div>
            </div>

            <button type="submit" class="btn btn-primary w-100 btn-login rounded-pill text-white fw-bold py-2">
                SIGN IN
            </button>
            
            <div class="text-center mt-4">
                <p class="small text-muted mb-1">Don't have an account?</p>
                <a href="register.php" class="text-decoration-none fw-bold">Create Account</a>
            </div>
        </form>
    </div>

</body>
</html>