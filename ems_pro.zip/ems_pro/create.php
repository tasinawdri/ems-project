<?php
session_start();
require 'config.php';
require 'functions.php';

// Check if admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    die("Access Denied");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $role = $_POST['role'];
    
    $error = "";

    // Validation: Check if email already exists
    $check_email = $pdo->prepare("SELECT COUNT(*) FROM users WHERE email = ?");
    $check_email->execute([$email]);
    if ($check_email->fetchColumn() > 0) {
        $error = "⚠️ Email address already exists! Please use a different email.";
    }

    // Validation: Check if username is empty
    if (empty($username)) {
        $error = "⚠️ Full name is required.";
    }

    // Validation: Check password length
    if (strlen($password) < 6) {
        $error = "⚠️ Password must be at least 6 characters long.";
    }

    // If no errors, create the user
    if (empty($error)) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $sql = "INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)";
        $stmt = $pdo->prepare($sql);
        
        if ($stmt->execute([$username, $email, $hashed_password, $role])) {
            // Log activity
            log_activity($_SESSION['user_id'], "Create User", "Created new user: " . $username);
            
            echo "<script>alert('✅ Employee created successfully!'); window.location='index.php';</script>";
            exit;
        } else {
            $error = "❌ Error creating employee. Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Employee | EMS Pro</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Segoe UI', sans-serif;
            padding: 20px;
        }
        .form-container {
            background: white;
            border-radius: 20px;
            padding: 50px;
            width: 100%;
            max-width: 500px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            backdrop-filter: blur(10px);
        }
        .form-header {
            text-align: center;
            margin-bottom: 40px;
        }
        .form-icon {
            width: 80px;
            height: 80px;
            background: linear-gradient(45deg, #0d6efd, #6610f2);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 36px;
            margin: 0 auto 20px;
            box-shadow: 0 4px 15px rgba(13, 110, 253, 0.4);
        }
        .form-header h2 {
            color: #2c3e50;
            font-weight: 700;
            margin-bottom: 5px;
        }
        .form-header p {
            color: #7f8c8d;
            font-size: 14px;
            margin-bottom: 0;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            color: #2c3e50;
            font-weight: 600;
            margin-bottom: 8px;
            display: block;
            font-size: 14px;
        }
        .form-control {
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            padding: 12px 16px;
            font-size: 14px;
            transition: all 0.3s ease;
        }
        .form-control:focus {
            border-color: #0d6efd;
            box-shadow: 0 0 0 3px rgba(13, 110, 253, 0.1);
        }
        .form-control::placeholder {
            color: #bbb;
        }
        .btn-submit {
            background: linear-gradient(45deg, #0d6efd, #6610f2);
            border: none;
            border-radius: 10px;
            padding: 12px 30px;
            color: white;
            font-weight: 600;
            width: 100%;
            font-size: 16px;
            transition: transform 0.2s, box-shadow 0.2s;
            cursor: pointer;
            margin-bottom: 10px;
        }
        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(13, 110, 253, 0.4);
            color: white;
        }
        .btn-cancel {
            background: #f0f0f0;
            border: none;
            border-radius: 10px;
            padding: 12px 30px;
            color: #666;
            font-weight: 600;
            width: 100%;
            font-size: 16px;
            transition: all 0.2s;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
        }
        .btn-cancel:hover {
            background: #e0e0e0;
            color: #333;
        }
        .alert {
            border-radius: 10px;
            border: none;
            margin-bottom: 20px;
        }
        .form-divider {
            text-align: center;
            margin: 25px 0;
            position: relative;
            color: #999;
            font-size: 12px;
        }
        .role-options {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
        }
    </style>
</head>
<body>

    <div class="form-container">
        <div class="form-header">
            <div class="form-icon">
                <i class="fa-solid fa-user-plus"></i>
            </div>
            <h2>Add New Employee</h2>
            <p>Create a new employee account</p>
        </div>

        <?php if (isset($error)): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="fa-solid fa-circle-exclamation me-2"></i>
                <?= htmlspecialchars($error) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <label for="username">
                    <i class="fa-solid fa-user text-primary me-2"></i>Full Name
                </label>
                <input type="text" id="username" name="username" class="form-control" 
                       placeholder="Enter employee name" required>
            </div>

            <div class="form-group">
                <label for="email">
                    <i class="fa-solid fa-envelope text-primary me-2"></i>Email Address
                </label>
                <input type="email" id="email" name="email" class="form-control" 
                       placeholder="Enter email address" required>
            </div>

            <div class="form-group">
                <label for="password">
                    <i class="fa-solid fa-lock text-primary me-2"></i>Password
                </label>
                <input type="password" id="password" name="password" class="form-control" 
                       placeholder="Create a strong password" required>
            </div>

            <div class="form-group">
                <label for="role">
                    <i class="fa-solid fa-shield text-primary me-2"></i>User Role
                </label>
                <select id="role" name="role" class="form-control" required>
                    <option value="" disabled selected>Select a role...</option>
                    <option value="employee">Employee</option>
                    <option value="admin">Administrator</option>
                </select>
            </div>

            <button type="submit" class="btn-submit">
                <i class="fa-solid fa-check me-2"></i>Create Employee
            </button>
            <a href="index.php" class="btn-cancel">
                <i class="fa-solid fa-arrow-left me-2"></i>Go Back
            </a>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>