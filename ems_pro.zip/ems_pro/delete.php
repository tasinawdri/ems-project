<?php
session_start();
include 'db.php';
include 'functions.php'; 

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // --- NEW: LOG ACTIVITY ---
    // We log this before the delete happens to capture the attempt
    log_activity($_SESSION['user_id'], "Delete User", "Deleted user ID: $id");
    // -------------------------

    // Execute Delete
    $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
    if ($stmt->execute([$id])) {
        // Redirect back to the user list
        header("Location: users.php?msg=deleted");
    } else {
        echo "Error deleting record.";
    }
} else {
    header("Location: users.php");
}
?>