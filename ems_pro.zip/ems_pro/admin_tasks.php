<?php
session_start();
require 'config.php';
require 'functions.php';

// Session Hijacking Validation
validate_session_security();
if ($_SESSION['role'] != 'admin') header("Location: index.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $pdo->prepare("INSERT INTO tasks (user_id, task_name, description, due_date) VALUES (?,?,?,?)")
        ->execute([$_POST['user_id'], $_POST['task_name'], $_POST['description'], $_POST['due_date']]);
    echo "<script>alert('Task Assigned!');</script>";
}
$users = $pdo->query("SELECT * FROM users")->fetchAll();
$tasks = $pdo->query("SELECT t.*, u.username FROM tasks t JOIN users u ON t.user_id = u.id")->fetchAll();
?>
<!DOCTYPE html>
<html>
<head><title>Task Manager</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body class="container mt-5">
    <div class="row">
        <div class="col-md-4">
            <div class="card p-3">
                <h4>Assign Task</h4>
                <form method="POST">
                    <select name="user_id" class="form-control mb-2"><?php foreach($users as $u): ?><option value="<?= $u['id'] ?>"><?= $u['username'] ?></option><?php endforeach; ?></select>
                    <input type="text" name="task_name" class="form-control mb-2" placeholder="Task Title" required>
                    <textarea name="description" class="form-control mb-2" placeholder="Description"></textarea>
                    <input type="date" name="due_date" class="form-control mb-2" required>
                    <button class="btn btn-primary w-100">Assign</button>
                </form>
            </div>
            <a href="index.php" class="btn btn-secondary mt-2 w-100">Back</a>
        </div>
        <div class="col-md-8">
            <h4>All Tasks</h4>
            <table class="table table-bordered">
                <tr><th>User</th><th>Task</th><th>Due</th><th>Status</th></tr>
                <?php foreach($tasks as $t): ?>
                <tr><td><?= $t['username'] ?></td><td><?= $t['task_name'] ?></td><td><?= $t['due_date'] ?></td><td><?= $t['status'] ?></td></tr>
                <?php endforeach; ?>
            </table>
        </div>
    </div>
</body>
</html>