<?php
// Set header to return JSON
header('Content-Type: application/json');

// API Key for authentication
$VALID_API_KEY = '12345';

// Get API key from query parameter
$api_key = $_GET['api_key'] ?? null;

// Validate API Key
if ($api_key !== $VALID_API_KEY) {
    http_response_code(401);
    echo json_encode([
        "status" => "error",
        "message" => "Invalid API Key"
    ]);
    exit;
}

// Include database config
require '../config.php';

try {
    // Fetch all users with their department information
    $sql = "SELECT u.id, u.username as name, u.email, u.role, d.name as dept 
            FROM users u 
            LEFT JOIN departments d ON u.department_id = d.id 
            ORDER BY u.id ASC";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Return success response with employee data
    http_response_code(200);
    echo json_encode([
        "status" => "success",
        "data" => $employees
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    
} catch (Exception $e) {
    // Return error response if database query fails
    http_response_code(500);
    echo json_encode([
        "status" => "error",
        "message" => "Database error: " . $e->getMessage()
    ]);
}
?>
