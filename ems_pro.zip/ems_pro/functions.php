<?php
// Function to validate session against hijacking attacks
function validate_session_security() {
    // Check if session exists
    if (!isset($_SESSION['user_id'])) {
        return false;
    }
    
    // Validate User Agent matches
    if (!isset($_SESSION['user_agent']) || $_SERVER['HTTP_USER_AGENT'] !== $_SESSION['user_agent']) {
        // Potential hijacking detected - destroy session
        session_destroy();
        header("Location: login.php?error=hijack_attempt");
        exit;
    }
    
    // Validate IP Address matches
    if (!isset($_SESSION['ip_address']) || $_SERVER['REMOTE_ADDR'] !== $_SESSION['ip_address']) {
        // IP changed - potential hijacking detected
        session_destroy();
        header("Location: login.php?error=hijack_attempt");
        exit;
    }
    
    return true;
}

// Function to check if the logged-in user has a specific permission
function has_permission($feature) {
    global $pdo;
    
    // Ensure user is logged in
    if (!isset($_SESSION['role'])) return false;
    $role = $_SESSION['role'];

    // Admin always has access to all features
    if ($role == 'admin') return true; 

    // Check DB for permission for other roles
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM permissions WHERE role = ? AND feature = ?");
    $stmt->execute([$role, $feature]);
    return $stmt->fetchColumn() > 0;
}

// Function to Enforce Access (Redirect if failed)
function enforce_permission($feature) {
    if (!has_permission($feature)) {
        echo "<div style='text-align:center; padding:50px; color:red;'>
                <h2>🚫 Access Denied</h2>
                <p>You do not have permission to access this page.</p>
                <a href='index.php'>Go Back</a>
              </div>";
        exit;
    }
}
// Helper function to record activity
function log_activity($user_id, $action, $details) {
    global $pdo;
    $ip = $_SERVER['REMOTE_ADDR'];
    $stmt = $pdo->prepare("INSERT INTO activity_logs (user_id, action, details, ip_address) VALUES (?, ?, ?, ?)");
    $stmt->execute([$user_id, $action, $details, $ip]);
}
?>