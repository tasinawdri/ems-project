<?php
session_start();
require 'config.php';
require 'functions.php';
// Session Hijacking Validation
validate_session_security();
if ($_SESSION['role'] != 'admin') header("Location: index.php");

// HANDLE APPROVAL (DEDUCT BALANCE)
if (isset($_GET['approve'])) {
    $id = $_GET['approve'];
    
    // 1. Get Leave Details
    $leave = $pdo->query("SELECT * FROM leaves WHERE id=$id")->fetch();
    $uid = $leave['user_id'];
    
    // 2. Calculate Days
    $start = strtotime($leave['start_date']);
    $end = strtotime($leave['end_date']);
    $days = ($end - $start) / (60 * 60 * 24) + 1;

    // 3. Deduct from User Balance
    $pdo->query("UPDATE users SET leave_balance = leave_balance - $days WHERE id=$uid");

    // 4. Mark Approved
    $pdo->query("UPDATE leaves SET status='Approved' WHERE id=$id");
    header("Location: admin_leaves.php");
}

if (isset($_GET['reject'])) {
    $pdo->query("UPDATE leaves SET status='Rejected' WHERE id=".$_GET['reject']);
    header("Location: admin_leaves.php");
}

// Fetch Pending Requests with User Balance
$leaves = $pdo->query("SELECT l.*, u.username, u.leave_balance FROM leaves l JOIN users u ON l.user_id=u.id WHERE l.status='Pending'")->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Smart Leave Manager</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-5">
    <h3>📋 Leave Approvals</h3>
    <a href="index.php" class="btn btn-secondary mb-3">Back</a>

    <table class="table table-bordered table-hover">
        <thead class="table-dark">
            <tr>
                <th>Employee</th>
                <th>Current Balance</th>
                <th>Request Days</th>
                <th>Reason</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($leaves as $l): 
                $d_days = (strtotime($l['end_date']) - strtotime($l['start_date'])) / (60*60*24) + 1;
                $has_balance = $l['leave_balance'] >= $d_days;
            ?>
            <tr class="<?= $has_balance ? '' : 'table-danger' ?>">
                <td><?= $l['username'] ?></td>
                <td class="fw-bold text-primary"><?= $l['leave_balance'] ?> Days</td>
                <td>
                    <?= $d_days ?> Days <br>
                    <small class="text-muted"><?= $l['start_date'] ?> to <?= $l['end_date'] ?></small>
                </td>
                <td><?= $l['reason'] ?></td>
                <td>
                    <?php if ($has_balance): ?>
                        <a href="?approve=<?= $l['id'] ?>" class="btn btn-success btn-sm">Approve</a>
                    <?php else: ?>
                        <button disabled class="btn btn-secondary btn-sm">Insufficient Balance</button>
                    <?php endif; ?>
                    <a href="?reject=<?= $l['id'] ?>" class="btn btn-danger btn-sm">Reject</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php if(count($leaves)==0) echo "<p class='text-center'>No pending requests.</p>"; ?>
</body>
</html>