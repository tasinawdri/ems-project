<?php
session_start();
require 'config.php';
require 'functions.php';

// Session Hijacking Validation
validate_session_security();

enforce_permission('manage_payroll');

if ($_SESSION['role'] != 'admin') header("Location: index.php");

$users = $pdo->query("SELECT * FROM users")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $uid = $_POST['user_id'];
    $month = date('Y-m');
    
    // 1. Fetch Salary Info
    $user = $pdo->query("SELECT base_salary FROM users WHERE id=$uid")->fetch();
    $base = $user['base_salary'];

    // 2. Fetch Attendance
    $days_worked = $pdo->query("SELECT COUNT(*) FROM attendance WHERE user_id=$uid AND date LIKE '$month%'")->fetchColumn();

    // 3. ADVANCED CALCULATIONS
    // Formula: (Base / 30) * Days Worked
    $earned_basic = ($base / 30) * $days_worked;

    // Allowances (Fixed % of Basic)
    $hra = $base * 0.40;      // House Rent Allowance (40%)
    $medical = $base * 0.10;  // Medical (10%)
    
    // Deductions
    $pf = $base * 0.12;       // Provident Fund (12%)
    $tax = $base * 0.05;      // Tax (5%)

    $bonus = $_POST['bonus']; // Manual Bonus

    // 4. ATTENDANCE-BASED BONUS LOGIC
    // Calculate total days in current month
    $total_days_in_month = cal_days_in_month(CAL_GREGORIAN, (int)date('m'), (int)date('Y'));
    
    // Calculate attendance percentage (considering only working days might be better, but using calendar days as per requirement)
    $attendance_percentage = ($days_worked / $total_days_in_month) * 100;
    
    // Apply tiered bonus/deduction
    if ($attendance_percentage > 90) {
        $bonus += 200;  // Add $200 for excellent attendance
        $bonus_message = "Excellent Attendance Bonus (+$200) Applied!";
    } elseif ($attendance_percentage < 50) {
        $bonus -= 100;  // Deduct $100 for poor attendance
        $bonus_message = "Low Attendance Deduction (-$100) Applied!";
    } else {
        $bonus_message = "";
    }

    // Final Net Salary
    $net_salary = ($earned_basic + $hra + $medical + $bonus) - ($pf + $tax);

    // 5. Save to DB
    $sql = "INSERT INTO payroll (user_id, month, days_worked, base_salary, hra, medical, bonus, pf, tax, net_salary) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $pdo->prepare($sql)->execute([$uid, $month, $days_worked, $base, $hra, $medical, $bonus, $pf, $tax, $net_salary]);

    $success_msg = "Payroll generated. Performance Bonus applied.";
    if ($bonus_message) {
        $success_msg .= " " . $bonus_message;
    }
    echo "<script>alert('$success_msg\\n\\nAttendance: " . round($attendance_percentage, 2) . "%\\nDays Worked: $days_worked/$total_days_in_month'); window.location='index.php';</script>";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Advanced Payroll</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-5">
    <div class="card p-4 mx-auto shadow" style="max-width: 600px;">
        <h3 class="text-center text-primary">💰 Generate Salary</h3>
        <p class="text-center text-muted">Includes Auto-Calculation for HRA (40%), Medical (10%), PF (12%), Tax (5%)</p>
        <div class="alert alert-info alert-sm">
            <strong>🎯 Attendance Bonus:</strong> 
            <br>✅ Attendance > 90%: +$200 bonus
            <br>❌ Attendance < 50%: -$100 deduction
        </div>
        <form method="POST">
            <div class="mb-3">
                <label>Select Employee</label>
                <select name="user_id" class="form-control">
                    <?php foreach($users as $u): ?>
                        <option value="<?= $u['id'] ?>"><?= $u['username'] ?> (Base: $<?= $u['base_salary'] ?>)</option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-3">
                <label>Performance Bonus ($)</label>
                <input type="number" name="bonus" class="form-control" value="0">
            </div>
            <button class="btn btn-primary w-100">Generate & Calculate</button>
            <a href="index.php" class="btn btn-secondary w-100 mt-2">Back</a>
        </form>
    </div>
</body>
</html>