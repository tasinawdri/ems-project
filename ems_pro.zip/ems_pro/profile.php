<?php
session_start();
require 'config.php';
require 'functions.php';
if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit; }
// Session Hijacking Validation
validate_session_security();

$id = $_SESSION['user_id'];
$msg = "";

// Handle Profile Update
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // 1. Update Password (if provided)
    if (!empty($_POST['password'])) {
        $pass = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $pdo->prepare("UPDATE users SET password=? WHERE id=?")->execute([$pass, $id]);
        $msg = "Password Updated! ";
    }

    // 2. Update Avatar (if uploaded)
    if (!empty($_FILES['avatar']['name'])) {
        $img = time() . "_" . $_FILES['avatar']['name'];
        move_uploaded_file($_FILES['avatar']['tmp_name'], "uploads/" . $img);
        $pdo->prepare("UPDATE users SET avatar=? WHERE id=?")->execute([$img, $id]);
        $_SESSION['avatar'] = $img; // Update Session
        $msg .= "Profile Picture Updated!";
    }
}

$u = $pdo->query("SELECT * FROM users WHERE id=$id")->fetch();
?>

<!DOCTYPE html>
<html>
<head>
    <title>My Profile</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="card shadow">
                <div class="card-header bg-primary text-white">My Profile Settings</div>
                <div class="card-body text-center">
                    
                    <img src="uploads/<?= $u['avatar'] ?>" class="rounded-circle mb-3 border" width="100" height="100">
                    <h4><?= $u['username'] ?></h4>
                    <p class="text-muted"><?= $u['email'] ?> | Role: <strong><?= ucfirst($u['role']) ?></strong></p>
                    <hr>

                    <?php if($msg) echo "<div class='alert alert-success'>$msg</div>"; ?>

                    <form method="POST" enctype="multipart/form-data" class="text-start">
                        <div class="mb-3">
                            <label>Change Profile Picture</label>
                            <input type="file" name="avatar" class="form-control">
                        </div>
                        <div class="mb-3">
                            <label>New Password (Leave blank to keep current)</label>
                            <input type="password" name="password" class="form-control" placeholder="******">
                        </div>
                        <button class="btn btn-success w-100">Save Changes</button>
                    </form>
                    
                    <a href="index.php" class="btn btn-link mt-3">Back to Dashboard</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>