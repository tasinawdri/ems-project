<?php
session_start();
require 'config.php';
require 'functions.php';

if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit; }

// Session Hijacking Validation
validate_session_security();

$user_id = $_SESSION['user_id'];
$today_date = date('Y-m-d');

// --- 1. HANDLE CSV EXPORT ---
if (isset($_GET['action']) && $_GET['action'] == 'export') {
    $m = $_GET['month'] ?? date('m'); $y = $_GET['year'] ?? date('Y');
    $stmt = $pdo->prepare("SELECT date, clock_in, clock_out FROM attendance WHERE user_id = ? AND MONTH(date) = ? AND YEAR(date) = ?");
    $stmt->execute([$user_id, $m, $y]);
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

    header('Content-Type: text/csv'); header('Content-Disposition: attachment; filename="Attendance_'.$y.'-'.$m.'.csv"');
    $output = fopen('php://output', 'w'); fputcsv($output, ['Date', 'In', 'Out', 'Hours']);
    foreach ($data as $row) {
        $hrs = ($row['clock_out']) ? round(abs(strtotime($row['clock_out']) - strtotime($row['clock_in']))/3600, 2) : 0;
        fputcsv($output, [$row['date'], $row['clock_in'], $row['clock_out'], $hrs]);
    }
    fclose($output); exit;
}

// --- 2. HANDLE ACTIONS ---
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['in'])) $pdo->prepare("INSERT INTO attendance (user_id, date, clock_in) VALUES (?, ?, NOW())")->execute([$user_id, $today_date]);
    if (isset($_POST['out'])) {
        $id = $pdo->query("SELECT id FROM attendance WHERE user_id=$user_id AND date='$today_date'")->fetchColumn();
        $pdo->prepare("UPDATE attendance SET clock_out = NOW() WHERE id = ?")->execute([$id]);
    }
    header("Location: attendance.php"); exit;
}

// --- 3. FETCH DATA ---
$today = $pdo->query("SELECT * FROM attendance WHERE user_id=$user_id AND date='$today_date'")->fetch();

$f_month = $_GET['month'] ?? date('m');
$f_year = $_GET['year'] ?? date('Y');
$history = $pdo->query("SELECT * FROM attendance WHERE user_id=$user_id AND MONTH(date)=$f_month AND YEAR(date)=$f_year ORDER BY date DESC")->fetchAll();

// --- 4. CALENDAR LOGIC ---
$days_in_month = cal_days_in_month(CAL_GREGORIAN, $f_month, $f_year);
$first_day_of_month = date('w', strtotime("$f_year-$f_month-01")); 
$attendance_map = [];
foreach ($history as $h) {
    $attendance_map[date('j', strtotime($h['date']))] = ($h['clock_out']) ? 'success' : 'warning';
}

// Share Links
$url = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
$mailto = "mailto:?body=$url";
$messenger = "fb-messenger://share/?link=$url";
?>

<!DOCTYPE html>
<html>
<head>
    <title>Attendance Calendar</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f4f6f9; }
        .cal-day { height: 80px; width: 14.28%; border: 1px solid #dee2e6; vertical-align: top; padding: 5px; background: white; }
        .cal-head { width: 14.28%; text-align: center; background: #343a40; color: white; padding: 10px 0; }
        .status-dot { height: 10px; width: 10px; border-radius: 50%; display: inline-block; }
        .today-highlight { border: 2px solid #0d6efd !important; background: #e7f1ff; }
    </style>
</head>
<body class="container py-5">

    <div class="d-flex justify-content-between mb-4">
        <h3><i class="fa-solid fa-calendar-days"></i> Attendance Portal</h3>
        <div>
            <a href="<?= $mailto ?>" class="btn btn-outline-danger btn-sm"><i class="fa-solid fa-envelope"></i></a>
            <a href="<?= $messenger ?>" class="btn btn-outline-primary btn-sm"><i class="fa-brands fa-facebook-messenger"></i></a>
            <a href="index.php" class="btn btn-secondary btn-sm ms-2">Back</a>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-4 mb-4">
            <div class="card shadow-sm text-center p-4 border-0 mb-4">
                <h6 class="text-muted"><?= date('l, d F Y') ?></h6>
                <h1 class="fw-bold my-2"><?= date('H:i') ?></h1>
                
                <form method="POST">
                    <?php if (!$today): ?>
                        <button name="in" class="btn btn-success w-100 btn-lg rounded-pill mt-3 shadow">Check In</button>
                    <?php elseif (!$today['clock_out']): ?>
                        <div class="alert alert-success py-1 mt-2">In: <?= date('H:i', strtotime($today['clock_in'])) ?></div>
                        <button name="out" class="btn btn-danger w-100 btn-lg rounded-pill mt-2 shadow">Check Out</button>
                    <?php else: ?>
                        <div class="alert alert-secondary py-1 mt-3">Shift Done (<?= round(abs(strtotime($today['clock_out']) - strtotime($today['clock_in']))/3600, 1) ?> hrs)</div>
                        <button disabled class="btn btn-secondary w-100 rounded-pill">Completed</button>
                    <?php endif; ?>
                </form>
            </div>

            <div class="card p-3 border-0 shadow-sm">
                <h6 class="fw-bold">Filter & Export</h6>
                <form method="GET" class="d-flex gap-2 mb-2">
                    <select name="month" class="form-select form-select-sm">
                        <?php for($m=1; $m<=12; $m++) echo "<option value='$m' ".($m==$f_month?'selected':'').">".date('M', mktime(0,0,0,$m,1))."</option>"; ?>
                    </select>
                    <select name="year" class="form-select form-select-sm">
                        <?php for($y=2023; $y<=date('Y'); $y++) echo "<option value='$y' ".($y==$f_year?'selected':'').">$y</option>"; ?>
                    </select>
                    <button class="btn btn-primary btn-sm"><i class="fa-solid fa-filter"></i></button>
                </form>
                <a href="?action=export&month=<?= $f_month ?>&year=<?= $f_year ?>" class="btn btn-success btn-sm w-100"><i class="fa-solid fa-download"></i> Download CSV</a>
            </div>
        </div>

        <div class="col-lg-8">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-white fw-bold py-3">
                    <i class="fa-solid fa-calendar"></i> Calendar View (<?= date('F Y', mktime(0,0,0,$f_month, 1, $f_year)) ?>)
                </div>
                <div class="card-body p-0">
                    <div class="d-flex flex-wrap">
                        <div class="cal-head">Sun</div><div class="cal-head">Mon</div><div class="cal-head">Tue</div>
                        <div class="cal-head">Wed</div><div class="cal-head">Thu</div><div class="cal-head">Fri</div><div class="cal-head">Sat</div>
                        
                        <?php for($i=0; $i<$first_day_of_month; $i++): ?>
                            <div class="cal-day bg-light"></div>
                        <?php endfor; ?>

                        <?php for($day=1; $day<=$days_in_month; $day++): 
                            $is_today = ($day == date('j') && $f_month == date('m') && $f_year == date('Y'));
                            $status = $attendance_map[$day] ?? '';
                            $bg_color = $status == 'success' ? '#d1e7dd' : ($status == 'warning' ? '#fff3cd' : 'white');
                        ?>
                            <div class="cal-day <?= $is_today ? 'today-highlight' : '' ?>" style="background-color: <?= $bg_color ?>;">
                                <div class="fw-bold d-flex justify-content-between">
                                    <span><?= $day ?></span>
                                    <?php if($status): ?>
                                        <i class="fa-solid fa-circle text-<?= $status ?> small"></i>
                                    <?php endif; ?>
                                </div>
                                <?php if($status == 'success'): ?>
                                    <small class="text-success d-block" style="font-size:10px; line-height:1.2;">Present</small>
                                <?php elseif($status == 'warning'): ?>
                                    <small class="text-warning d-block" style="font-size:10px; line-height:1.2;">Active</small>
                                <?php endif; ?>
                            </div>
                        <?php endfor; ?>
                    </div>
                </div>
            </div>
            
            <div class="mt-4">
                <h6>Recent Activity List</h6>
                <table class="table table-sm table-bordered bg-white">
                    <thead class="table-light"><tr><th>Date</th><th>In</th><th>Out</th><th>Status</th></tr></thead>
                    <tbody>
                        <?php foreach($history as $h): ?>
                        <tr>
                            <td><?= date('d M', strtotime($h['date'])) ?></td>
                            <td><?= date('H:i', strtotime($h['clock_in'])) ?></td>
                            <td><?= $h['clock_out'] ? date('H:i', strtotime($h['clock_out'])) : '--' ?></td>
                            <td><span class="badge bg-<?= $h['clock_out']?'success':'warning' ?>"><?= $h['clock_out']?'Done':'Active' ?></span></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</body>
</html>