<?php
session_start();
require 'config.php';
require 'functions.php';
// Session Hijacking Validation
validate_session_security();
if ($_SESSION['role'] != 'admin') header("Location: index.php");

// Handle Delete
if (isset($_GET['delete'])) {
    $pdo->prepare("DELETE FROM notices WHERE id=?")->execute([$_GET['delete']]);
    header("Location: admin_notices.php");
}

// Handle Add
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $pdo->prepare("INSERT INTO notices (title, message, date) VALUES (?,?,?)")
        ->execute([$_POST['title'], $_POST['message'], $_POST['date']]);
    echo "<script>alert('Notice Posted!');</script>";
}

$notices = $pdo->query("SELECT * FROM notices ORDER BY date DESC")->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Notices</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-light container mt-5">
    <div class="d-flex justify-content-between mb-4">
        <h3><i class="fa-solid fa-bullhorn"></i> Notice Board Manager</h3>
        <a href="index.php" class="btn btn-secondary">Back to Dashboard</a>
    </div>

    <div class="row">
        <div class="col-md-4">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-primary text-white">Post New Notice</div>
                <div class="card-body">
                    <form method="POST">
                        <div class="mb-3">
                            <label>Title</label>
                            <input type="text" name="title" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label>Date</label>
                            <input type="date" name="date" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label>Message</label>
                            <textarea name="message" class="form-control" rows="4" required></textarea>
                        </div>
                        <button class="btn btn-primary w-100">Post Notice</button>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-8">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-dark text-white">Active Notices</div>
                <div class="card-body p-0">
                    <table class="table table-hover mb-0">
                        <thead><tr><th>Date</th><th>Title</th><th>Message</th><th>Action</th></tr></thead>
                        <tbody>
                            <?php foreach($notices as $n): ?>
                            <tr>
                                <td><?= $n['date'] ?></td>
                                <td class="fw-bold"><?= $n['title'] ?></td>
                                <td><?= substr($n['message'], 0, 50) ?>...</td>
                                <td><a href="?delete=<?= $n['id'] ?>" class="btn btn-sm btn-danger"><i class="fa-solid fa-trash"></i></a></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html>