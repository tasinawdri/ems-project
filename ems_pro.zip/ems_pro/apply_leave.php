<?php
session_start();
require 'config.php';
require 'functions.php';

// Check if logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Session Hijacking Validation
validate_session_security();$user_id = $_SESSION['user_id'];

// 1. Handle New Leave Submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $type = $_POST['type'];
    $start = $_POST['start'];
    $end = $_POST['end'];
    $reason = $_POST['reason'];

    // Insert into DB
    $sql = "INSERT INTO leaves (user_id, leave_type, start_date, end_date, reason) VALUES (?, ?, ?, ?, ?)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$user_id, $type, $start, $end, $reason]);

    echo "<script>alert('Leave application submitted! Wait for approval.'); window.location='apply_leave.php';</script>";
}

// 2. Fetch My Leave History
$stmt = $pdo->prepare("SELECT * FROM leaves WHERE user_id = ? ORDER BY id DESC");
$stmt->execute([$user_id]);
$my_leaves = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Apply & View Leave</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="container mt-5 mb-5">
    
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3><i class="fa-solid fa-calendar-check"></i> My Leave Portal</h3>
        <a href="index.php" class="btn btn-secondary">Back to Dashboard</a>
    </div>

    <div class="row">
        
        <div class="col-md-4">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <i class="fa-solid fa-pen-to-square"></i> Apply New Leave
                </div>
                <div class="card-body">
                    <form method="POST">
                        <div class="mb-3">
                            <label>Leave Type</label>
                            <select name="type" class="form-control" required>
                                <option>Sick Leave</option>
                                <option>Casual Leave</option>
                                <option>Vacation</option>
                                <option>Personal</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label>Start Date</label>
                            <input type="date" name="start" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label>End Date</label>
                            <input type="date" name="end" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label>Reason</label>
                            <textarea name="reason" class="form-control" rows="3" placeholder="Why do you need leave?" required></textarea>
                        </div>
                        <button class="btn btn-primary w-100">Submit Application</button>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-8">
            <div class="card shadow-sm">
                <div class="card-header bg-light fw-bold">
                    <i class="fa-solid fa-clock-rotate-left"></i> My Application History
                </div>
                <div class="card-body">
                    <table class="table table-hover align-middle">
                        <thead class="table-dark">
                            <tr>
                                <th>Type</th>
                                <th>Dates</th>
                                <th>Reason</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($my_leaves as $leave): ?>
                            <tr>
                                <td><?= htmlspecialchars($leave['leave_type']) ?></td>
                                <td>
                                    <small class="text-muted">From:</small> <?= $leave['start_date'] ?><br>
                                    <small class="text-muted">To:</small> <?= $leave['end_date'] ?>
                                </td>
                                <td><?= htmlspecialchars($leave['reason']) ?></td>
                                <td>
                                    <?php 
                                        if ($leave['status'] == 'Approved') {
                                            echo '<span class="badge bg-success"><i class="fa-solid fa-check"></i> Approved</span>';
                                        } elseif ($leave['status'] == 'Rejected') {
                                            echo '<span class="badge bg-danger"><i class="fa-solid fa-xmark"></i> Rejected</span>';
                                        } else {
                                            echo '<span class="badge bg-warning text-dark"><i class="fa-solid fa-hourglass-half"></i> Pending</span>';
                                        }
                                    ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>

                            <?php if (count($my_leaves) == 0): ?>
                                <tr>
                                    <td colspan="4" class="text-center text-muted p-4">You have not applied for any leave yet.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
</body>
</html>