<?php
session_start();
require 'config.php';
require 'functions.php';

// Session Hijacking Validation
validate_session_security();

// Access Control: Only 'admin' role can access this
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') { 
    header("Location: index.php"); 
    exit; 
}

// --- 1. HANDLE FORM SUBMISSION ---
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Clear all existing permissions first
    $pdo->query("TRUNCATE TABLE permissions");

    // Re-insert selected permissions
    if (isset($_POST['perms'])) {
        $stmt = $pdo->prepare("INSERT INTO permissions (role, feature) VALUES (?, ?)");
        foreach ($_POST['perms'] as $role => $features) {
            foreach ($features as $feature) {
                $stmt->execute([$role, $feature]);
            }
        }
    }
    echo "<script>alert('Permissions Updated Successfully!'); window.location='admin_permissions.php';</script>";
}

// --- 2. DEFINE ALL AVAILABLE FEATURES ---
// These keys must match the checks you use in enforce_permission('key')
$all_features = [
    'General Access' => [
        'view_dashboard' => 'View Dashboard',
        'view_reports'   => 'View Reports & Analytics',
        'view_salary'    => 'View Own Salary',
        'view_tasks'     => 'View Own Tasks',
    ],
    'Management' => [
        'manage_users'      => 'Add/Edit Employees',
        'delete_users'      => 'Delete Employees',
        'manage_attendance' => 'Manage Attendance (Edit/Export)',
        'manage_leaves'     => 'Approve/Reject Leaves',
        'manage_payroll'    => 'Generate Payroll',
        'manage_tasks'      => 'Assign Tasks',
        'manage_notices'    => 'Post Notices',
    ],
    'Employee Functions' => [
        'mark_attendance' => 'Clock In/Out',
        'apply_leave'     => 'Apply for Leave',
    ]
];

// --- 3. FETCH CURRENT PERMISSIONS (THE FIX) ---
// We select 'role' FIRST so PDO groups the array by role (admin/employee)
$stmt = $pdo->query("SELECT role, feature FROM permissions");
$current_perms = $stmt->fetchAll(PDO::FETCH_GROUP | PDO::FETCH_COLUMN);

// Example structure of $current_perms after fix:
// [
//    'admin' => ['manage_users', 'view_dashboard', ...],
//    'employee' => ['view_dashboard', 'mark_attendance', ...]
// ]
?>

<!DOCTYPE html>
<html>
<head>
    <title>Access Control Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background-color: #f8f9fa; }
        .feature-category { background-color: #e9ecef; font-weight: bold; }
    </style>
</head>
<body class="container mt-5 mb-5">
    
    <div class="card shadow-lg border-0">
        <div class="card-header bg-dark text-white d-flex justify-content-between align-items-center">
            <h4 class="mb-0"><i class="fa-solid fa-user-shield"></i> Access Control Panel</h4>
            <a href="index.php" class="btn btn-secondary btn-sm">Back to Dashboard</a>
        </div>
        
        <div class="card-body">
            <p class="text-muted">Check the boxes to grant permissions to specific roles. Changes apply immediately.</p>
            
            <form method="POST">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover text-center align-middle">
                        <thead class="table-primary">
                            <tr>
                                <th class="text-start" style="width: 40%;">Feature / Module</th>
                                <th style="width: 30%;">Admin</th>
                                <th style="width: 30%;">Employee</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($all_features as $category => $features): ?>
                                <tr class="feature-category">
                                    <td class="text-start ps-3 text-uppercase small text-muted" colspan="3">
                                        <?= $category ?>
                                    </td>
                                </tr>

                                <?php foreach ($features as $slug => $label): ?>
                                <tr>
                                    <td class="text-start ps-4 fw-bold">
                                        <?= $label ?> 
                                        <small class="text-muted d-block" style="font-size: 0.75rem; font-weight: normal;"><?= $slug ?></small>
                                    </td>
                                    
                                    <td>
                                        <div class="form-check d-flex justify-content-center">
                                            <input type="checkbox" name="perms[admin][]" value="<?= $slug ?>" 
                                                class="form-check-input border-secondary" style="transform: scale(1.3);"
                                                <?php 
                                                    // Check if 'admin' exists in array AND if the feature is in the admin list
                                                    if (isset($current_perms['admin']) && in_array($slug, $current_perms['admin'])) {
                                                        echo "checked";
                                                    }
                                                ?>
                                            >
                                        </div>
                                    </td>

                                    <td>
                                        <div class="form-check d-flex justify-content-center">
                                            <input type="checkbox" name="perms[employee][]" value="<?= $slug ?>" 
                                                class="form-check-input border-secondary" style="transform: scale(1.3);"
                                                <?php 
                                                    // Check if 'employee' exists in array AND if the feature is in the employee list
                                                    if (isset($current_perms['employee']) && in_array($slug, $current_perms['employee'])) {
                                                        echo "checked";
                                                    }
                                                ?>
                                            >
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <div class="d-grid gap-2 mt-3">
                    <button class="btn btn-success btn-lg shadow">
                        <i class="fa-solid fa-save"></i> Save Permissions
                    </button>
                </div>
            </form>
        </div>
    </div>

</body>
</html>