<?php
session_start();
require 'config.php';

// Fetch departments for dropdown
$departments = [];
try {
    $departments = $pdo->query("SELECT * FROM departments")->fetchAll();
} catch (PDOException $e) {
    // Keeps array empty if table doesn't exist yet
}

$msg = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $dept_id = $_POST['dept_id'] ?? 1; // Default to ID 1 if not selected

    // Basic Validation
    if (empty($username) || empty($email) || empty($password)) {
        $msg = "<div class='alert alert-danger'>All fields are required.</div>";
    } else {
        // Hash Password
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        
        try {
            $sql = "INSERT INTO users (username, email, password, role, department_id, avatar) VALUES (?, ?, ?, 'employee', ?, 'default.png')";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$username, $email, $hashed_password, $dept_id]);
            
            $msg = "<div class='alert alert-success'>Account Created! <a href='login.php' class='fw-bold'>Login Now</a></div>";
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) {
                $msg = "<div class='alert alert-warning'>Email already exists.</div>";
            } else {
                $msg = "<div class='alert alert-danger'>Error: " . $e->getMessage() . "</div>";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register | EMS Pro</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Segoe UI', sans-serif;
            padding: 20px;
        }
        .card-custom {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 40px;
            width: 100%;
            max-width: 450px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.2);
        }
        .btn-register {
            background: linear-gradient(45deg, #0d6efd, #6610f2);
            border: none;
            transition: transform 0.2s;
        }
        .btn-register:hover { transform: scale(1.02); }
    </style>
</head>
<body>

<div class="card-custom">
    <h3 class="text-center fw-bold mb-2">Create Account</h3>
    <p class="text-center text-muted mb-4">Join the EMS Team</p>
    
    <?= $msg ?>

    <form method="POST">
        <div class="mb-3">
            <label class="form-label fw-bold small text-muted">FULL NAME</label>
            <div class="input-group">
                <span class="input-group-text bg-light border-end-0"><i class="fa-solid fa-user"></i></span>
                <input type="text" name="username" class="form-control bg-light border-start-0" placeholder="John Doe" required>
            </div>
        </div>

        <div class="mb-3">
            <label class="form-label fw-bold small text-muted">EMAIL</label>
            <div class="input-group">
                <span class="input-group-text bg-light border-end-0"><i class="fa-solid fa-envelope"></i></span>
                <input type="email" name="email" class="form-control bg-light border-start-0" placeholder="name@company.com" required>
            </div>
        </div>

        <div class="mb-3">
            <label class="form-label fw-bold small text-muted">DEPARTMENT</label>
            <div class="input-group">
                <span class="input-group-text bg-light border-end-0"><i class="fa-solid fa-building"></i></span>
                <select name="dept_id" class="form-select bg-light border-start-0" required>
                    <option value="" disabled selected>Select Department</option>
                    <?php foreach($departments as $dept): ?>
                        <option value="<?= $dept['id'] ?>"><?= $dept['name'] ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <div class="mb-4">
            <label class="form-label fw-bold small text-muted">PASSWORD</label>
            <div class="input-group">
                <span class="input-group-text bg-light border-end-0"><i class="fa-solid fa-lock"></i></span>
                <input type="password" name="password" class="form-control bg-light border-start-0" placeholder="Create Password" required>
            </div>
        </div>

        <button type="submit" class="btn btn-primary w-100 btn-register py-2 rounded-pill fw-bold">
            REGISTER
        </button>

        <div class="text-center mt-4">
            <span class="text-muted small">Already have an account?</span> 
            <a href="login.php" class="text-primary fw-bold text-decoration-none small">Sign In</a>
        </div>
    </form>
</div>

</body>
</html>