<?php
require 'config.php';
header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="employees.csv"');
$output = fopen('php://output', 'w');
fputcsv($output, ['ID', 'Username', 'Email', 'Role', 'Department', 'Salary']);
$stmt = $pdo->query("SELECT u.id, u.username, u.email, u.role, d.name, u.base_salary FROM users u LEFT JOIN departments d ON u.department_id = d.id");
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) fputcsv($output, $row);
fclose($output);
?>