<?php
session_start();
require 'config.php';
require 'functions.php';

if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit; }

// Session Hijacking Validation
validate_session_security();
$id = $_GET['id'];
$p = $pdo->query("SELECT p.*, u.username, u.email, d.name as dept FROM payroll p JOIN users u ON p.user_id=u.id LEFT JOIN departments d ON u.department_id=d.id WHERE p.id=$id")->fetch();
?>
<!DOCTYPE html>
<html>
<body onload="window.print()" style="font-family: Arial, sans-serif; padding: 40px; background: #f4f4f4;">
    
    <div style="max-width: 700px; margin: auto; background: white; padding: 30px; border: 1px solid #ddd; box-shadow: 0 0 10px rgba(0,0,0,0.1);">
        
        <div style="text-align: center; border-bottom: 2px solid #333; padding-bottom: 20px; margin-bottom: 20px;">
            <h1 style="margin:0;">COMPANY NAME</h1>
            <p>123 Business Street, Tech City</p>
            <h3>SALARY SLIP: <?= date('F Y', strtotime($p['month'])) ?></h3>
        </div>

        <table style="width: 100%; margin-bottom: 20px;">
            <tr>
                <td><strong>Employee:</strong> <?= $p['username'] ?></td>
                <td style="text-align: right;"><strong>Payslip ID:</strong> #<?= str_pad($p['id'], 5, '0', STR_PAD_LEFT) ?></td>
            </tr>
            <tr>
                <td><strong>Department:</strong> <?= $p['dept'] ?></td>
                <td style="text-align: right;"><strong>Days Worked:</strong> <?= $p['days_worked'] ?></td>
            </tr>
        </table>

        <table style="width: 100%; border-collapse: collapse; border: 1px solid #ddd;">
            <tr style="background: #eee;">
                <th style="padding: 10px; border: 1px solid #ddd; text-align: left;">Earnings</th>
                <th style="padding: 10px; border: 1px solid #ddd; text-align: right;">Amount ($)</th>
                <th style="padding: 10px; border: 1px solid #ddd; text-align: left;">Deductions</th>
                <th style="padding: 10px; border: 1px solid #ddd; text-align: right;">Amount ($)</th>
            </tr>
            <tr>
                <td style="padding: 10px; border: 1px solid #ddd;">Basic Salary</td>
                <td style="padding: 10px; border: 1px solid #ddd; text-align: right;"><?= $p['base_salary'] ?></td>
                <td style="padding: 10px; border: 1px solid #ddd;">Provident Fund (12%)</td>
                <td style="padding: 10px; border: 1px solid #ddd; text-align: right; color: red;">-<?= $p['pf'] ?></td>
            </tr>
            <tr>
                <td style="padding: 10px; border: 1px solid #ddd;">HRA (40%)</td>
                <td style="padding: 10px; border: 1px solid #ddd; text-align: right;"><?= $p['hra'] ?></td>
                <td style="padding: 10px; border: 1px solid #ddd;">Tax (5%)</td>
                <td style="padding: 10px; border: 1px solid #ddd; text-align: right; color: red;">-<?= $p['tax'] ?></td>
            </tr>
            <tr>
                <td style="padding: 10px; border: 1px solid #ddd;">Medical (10%)</td>
                <td style="padding: 10px; border: 1px solid #ddd; text-align: right;"><?= $p['medical'] ?></td>
                <td style="padding: 10px; border: 1px solid #ddd;"></td>
                <td style="padding: 10px; border: 1px solid #ddd;"></td>
            </tr>
            <tr>
                <td style="padding: 10px; border: 1px solid #ddd;">Bonus</td>
                <td style="padding: 10px; border: 1px solid #ddd; text-align: right;"><?= $p['bonus'] ?></td>
                <td style="padding: 10px; border: 1px solid #ddd;"></td>
                <td style="padding: 10px; border: 1px solid #ddd;"></td>
            </tr>
            <tr style="background: #333; color: white;">
                <td style="padding: 10px;"><strong>NET PAYABLE</strong></td>
                <td style="padding: 10px; text-align: right;"></td>
                <td style="padding: 10px;"></td>
                <td style="padding: 10px; text-align: right; font-size: 1.2em;"><strong>$<?= number_format($p['net_salary'], 2) ?></strong></td>
            </tr>
        </table>
        
        <p style="margin-top: 30px; text-align: center; font-size: 0.8em; color: #777;">This is a computer-generated document.</p>

    </div>
</body>
</html>